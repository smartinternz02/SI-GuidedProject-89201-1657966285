
import requests
import json
import numpy as np  # used for numerical analysis
from flask import Flask, render_template, request  # Flask is a application used to run/serve our application
# request is used to access the file which is uploaded by the user in our application
# render_template is used for rendering the html pages
from tensorflow.keras.models import load_model  # we are loading our model from keras
# NOTE: you must manually set API_KEY below using information retrieved from your IBM Cloud account.
API_KEY = "fdxd7UYszu5LaSkURhcCqN6l7T_Xin9FU6gkd249nX7W"
token_response = requests.post('https://iam.cloud.ibm.com/identity/token', data={"apikey":
 API_KEY, "grant_type": 'urn:ibm:params:oauth:grant-type:apikey'})
mltoken = token_response.json()["access_token"]

header = {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + mltoken}

# NOTE: manually define and pass the array(s) of values to be scored in the next line
#payload_scoring = {"input_data": [{"field": [array_of_input_fields], "values": [array_of_values_to_be_scored, another_array_of_values_to_be_scored]}]}

#response_scoring = requests.post('https://us-south.ml.cloud.ibm.com/ml/v4/deployments/ca2da7d9-a61d-462f-a92b-fcffc6b3ef3a/predictions?version=2022-08-01', json=payload_scoring,
headers=({'Authorization': 'Bearer ' + mltoken})
#print("Scoring response")
#print(response_scoring.json())




app = Flask(__name__)  # our flask app
model = load_model('D:/InternshipProject/SharedFile/crude_oil_project_files/flask/crude_oil_IBM.h5')  # loading the model in the flask app


@app.route('/')  # rendering html template
def home():
    return render_template("index.html")  # rendering html template


@app.route('/about')
def home1():
    return render_template("index.html")  # rendering html template


@app.route('/predict')
def home2():
    return render_template("web.html")  # rendering html template


@app.route('/login', methods=['POST'])  # route for our prediction
def login():
    a = request.form['year1']
    b = request.form['year2']
    c = request.form['year3']
    d = request.form['year4']
    e = request.form['year5']
    f = request.form['year6']
    g = request.form['year7']
    h = request.form['year8']
    i = request.form['year9']
    j = request.form['year10']  # requesting the file
    x_input = [[float(a), float(b), float(c), float(d), float(e), float(f), float(g), float(h), float(i), float(j)]]
    print(x_input)
    lst_output = model.predict(x_input)
    lst_output = np.round(lst_output[0][0], 2)
    return render_template("web.html", showcase='The Predicted crude oil price is : Rs. '+str(lst_output))


if __name__ == '__main__':
    app.run(debug=False)
